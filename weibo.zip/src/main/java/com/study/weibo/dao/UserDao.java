package com.study.weibo.dao;

import com.study.weibo.entity.User;
import org.springframework.stereotype.Controller;




@Controller
    public interface UserDao {
        public void insertUser(User u);
        public User login(String loginname,String loginpwd);

}
