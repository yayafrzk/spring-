package com.study.weibo.dao;

import com.study.weibo.entity.WeiBo;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public interface WeiBoDao {
    public List<WeiBo> selectAll();
    public void insertWeiBo(WeiBo wb);
}
