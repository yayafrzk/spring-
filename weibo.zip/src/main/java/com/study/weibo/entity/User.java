package com.study.weibo.entity;

public class User {
    private int id;
    private String nickname;
    private String loginname;
    private String loginpwd;
    private String photo;
    private int score;
    private int attionCount;

    public int getId() {
        return id;
    }

    public String getNickname() {
        return nickname;
    }

    public String getLoginname() {
        return loginname;
    }

    public String getLoginpwd() {
        return loginpwd;
    }

    public String getPhoto() {
        return photo;
    }

    public int getScore() {
        return score;
    }

    public int getAttionCount() {
        return attionCount;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    public void setLoginpwd(String loginpwd) {
        this.loginpwd = loginpwd;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setAttionCount(int attionCount) {
        this.attionCount = attionCount;
    }
}
