package com.study.weibo.controller;


import com.study.weibo.dao.UserDao;
import com.study.weibo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpSession;


@Controller
public class UserController {
    @Autowired
    private UserDao dao;
    @GetMapping("/login")
    public String login(){
        return "login";
    }
    @PostMapping("/login")
    public String login(String uname, String upwd, HttpSession session, Model m){
        User u=dao.login(uname,upwd);
        if(u==null){
            m.addAttribute("err","用户名或密码不对");
            return "login";
        }
      session.setAttribute("user",u);
        return "redirect:index";
    }

    @GetMapping("/reg")
    public String reg(){
        return "reg";
    }

    @PostMapping("/reg")
    public String reg(User u){
        u.setScore(20);
        u.setAttionCount(0);
        dao.insertUser(u);
        return null;
    }


}
