package com.study.weibo.controller;

import com.study.weibo.dao.WeiBoDao;
import com.study.weibo.entity.User;
import com.study.weibo.entity.WeiBo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
public class WeiBoController {
    @Autowired
    private WeiBoDao dao;

    @GetMapping("/index")
    public String searchAll(Model m){
        List<WeiBo>list=dao.selectAll();
        m.addAttribute("weibos",list);
        return "list";
    }

    @GetMapping("/add")
    public String add(){
        return "add";
    }

    @PostMapping("/add")
    public String add(WeiBo wb, HttpSession session){
        User u=(User) session.getAttribute("user");
        wb.setUserId(u.getId());
        wb.setCreatetime(new Date());
        wb.setReadcount(0);
        dao.insertWeiBo(wb);
        return "redirect:index";
    }


}
