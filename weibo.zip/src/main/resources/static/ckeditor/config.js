/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function (config) {
    // Define changes to default configuration here. For example:
    config.language = 'zh-cn';
    // config.uiColor = '#AADC6E';
    config.toolbar = "my";
    config.toolbar_my = [
        ['Source', '-', 'Bold', 'Italic', 'Underline']
        , ['Link', 'Smiley']
        , ['Format', 'FontSize']
        , ['TextColor', 'BGColor']
    ];
    config.toolbar_good = [
        ['Source', '-', 'Bold', 'Italic', 'Underline']
        , ['Link', 'Smiley']

    ];

};









